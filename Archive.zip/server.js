(function(root, factory) {

    'use strict';

    if (typeof define === 'function' && define.amd)
        define(function() {
            return (root.iframeResizeServer = factory());
        });
    else
        root.iframeResizeServer = factory();

}(this, function() {

    'use strict';

    return (function() {

        var source, origin;
        var body = document.body,
            html = document.documentElement,
            height = Math.max(body.offsetHeight, html.offsetHeight);

        function resize() {
            console.log('calculando o resize...')
            var newHeight = Math.max(body.offsetHeight, html.offsetHeight);
            if (newHeight !== height) {
                height = newHeight;
                if (source && origin)
                    source.postMessage(height, origin);
            }
        }

        function recebe(event) {
            if (event.data === 'init') {
                source = event.source;
                origin = event.origin;
                source.postMessage('initiate', origin);
            }
        }

        function addEv(el, eventName, handler, usarCaptura) {
            usarCaptura = usarCaptura || false;
            if (el.addEventListener)
                el.addEventListener(eventName, handler, usarCaptura);
            else
                el.attachEvent('on' + eventName, function() {
                    handler.call(el);
                });
        }

        return {
            init: function() {
                window.setInterval(function() {
                    resize();
                }, 100);

                addEv(window, 'message', recebe);
            }
        };
    })();
}));